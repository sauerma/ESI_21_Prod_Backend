var config = {};

config.host = 'production.crosh4an9ahm.eu-central-1.rds.amazonaws.com';
config.user = 'production';
config.password = 'Esi-sose21';
config.port = '3306';
config.database = 'production'

module.exports = config;